Quick readme for the class structures in the example:-

superclass is: phoneSuperClass
subclasses are:-
  - smartphoneSubClass
  - nonSmartphoneSubClass

Getter n Setters for smartphoneSubClass:-   
  - setPhoneName, getPhoneName
  - setPhoneModel, getPhoneModel
  - setPhoneProcessor, getPhoneProcessor
  - setPhoneRam, getPhoneRam
  - setPhoneMemory, getPhoneMemory
  - setTouchScreen, getTouchScreen
  - setCapacitive, getCapacitive

Getter n Setters for nonSmartphoneSubClass:-

  - setPhoneName, getPhoneName
  - setPhoneModel, getPhoneModel
  - setPhoneProcessor, getPhoneProcessor
  - setPhoneRam, getPhoneRam
  - setPhoneMemory, getPhoneMemory
  - setTouchScreen, getTouchScreen
  - setCapacitive, getCapacitive

Known issue: Skipped button-click implementation in the absence of an ajax-url to get the offer-data.
